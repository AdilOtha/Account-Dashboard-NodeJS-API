module.exports = {
    HOST: "localhost",
    USER: "root",
    PASSWORD: "",
    DB: "floatbot",
    CONNECTION_LIMIT: 10
};